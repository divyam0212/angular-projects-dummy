import { Component } from '@angular/core';
import { Fruit } from './fruit';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  fruit:Fruit;
  length:number=10;
  
  constructor(){
    this.fruit=new Fruit();
  }
}
