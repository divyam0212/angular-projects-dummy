export class Fruit{
  name:string;
  color:string;
  person:string;
}